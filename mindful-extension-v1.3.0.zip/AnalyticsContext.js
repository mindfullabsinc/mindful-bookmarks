var c=Object.defineProperty;var t=(e,s)=>c(e,"name",{value:s,configurable:!0});import{R as n}from"./constants.js";const o={capture:t(()=>{},"capture"),identify:t(()=>{},"identify"),optOut:!1,setOptOut:t(()=>{},"setOptOut"),userId:void 0},a=n.createContext(null);function i(){return n.useContext(a)??o}t(i,"useAnalytics");export{a as A,i as u};
//# sourceMappingURL=AnalyticsContext.js.map
