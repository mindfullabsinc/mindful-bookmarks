var w=Object.defineProperty;var a=(t,e)=>w(t,"name",{value:e,configurable:!0});import{r as n}from"./constants.js";/**
 * @license lucide-react v0.542.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const f=a(t=>t.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),"toKebabCase"),h=a(t=>t.replace(/^([A-Z])|[\s-_]+(\w)/g,(e,r,o)=>o?o.toUpperCase():r.toLowerCase()),"toCamelCase"),l=a(t=>{const e=h(t);return e.charAt(0).toUpperCase()+e.slice(1)},"toPascalCase"),u=a((...t)=>t.filter((e,r,o)=>!!e&&e.trim()!==""&&o.indexOf(e)===r).join(" ").trim(),"mergeClasses"),g=a(t=>{for(const e in t)if(e.startsWith("aria-")||e==="role"||e==="title")return!0},"hasA11yProp");/**
 * @license lucide-react v0.542.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var A={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.542.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const b=n.forwardRef(({color:t="currentColor",size:e=24,strokeWidth:r=2,absoluteStrokeWidth:o,className:c="",children:s,iconNode:p,...i},m)=>n.createElement("svg",{ref:m,...A,width:e,height:e,stroke:t,strokeWidth:o?Number(r)*24/Number(e):r,className:u("lucide",c),...!s&&!g(i)&&{"aria-hidden":"true"},...i},[...p.map(([d,C])=>n.createElement(d,C)),...Array.isArray(s)?s:[s]]));/**
 * @license lucide-react v0.542.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const L=a((t,e)=>{const r=n.forwardRef(({className:o,...c},s)=>n.createElement(b,{ref:s,iconNode:e,className:u(`lucide-${f(l(t))}`,`lucide-${t}`,o),...c}));return r.displayName=l(t),r},"createLucideIcon");export{L as c};
//# sourceMappingURL=createLucideIcon.js.map
